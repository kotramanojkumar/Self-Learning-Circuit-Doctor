# Self-Learning Circuit Doctor: Voltage-Signature-Based Fault Detection in DC Circuits
**B.Tech Project | Basic Electrical & Electronics Engineering (BEEE)**

---

## ⚡ Project Overview

The **Self-Learning Circuit Doctor** is an automated, software-driven diagnostic engine designed to detect, diagnose, and localize component failures in a four-resistor DC bridge/ladder network. By sampling a 3-dimensional multi-signal signature vector comprising:
- **Node A Voltage ($V_A$)** in Volts
- **Node B Voltage ($V_B$)** in Volts
- **Total Source Current ($I_s$)** in milliamperes

the system maps the electrical operating state into a standardized feature space and applies a **Standardized Nearest-Centroid Classifier** to isolate faults in under 5 milliseconds.

### 🌟 Key Highlights
- **100.00% Test Accuracy:** Evaluated across 390 held-out test samples under 5% component manufacturing tolerances and DMM sensor noise.
- **Zero Hardware Required:** Fully simulated and cross-validated against the online [Falstad Circuit Simulator](https://www.falstad.com/circuit/) (SPICE Modified Nodal Analysis engine) and an exact Python mathematical model.
- **Ambiguity Resolution:** Demonstrates how measuring source current $I_s$ definitively resolves classic diagnostic deadlocks (e.g. distinguishing $R_1$ Open from $R_2$ Short, where both node voltages are $0.0\text{ V}$).
- **Supervised Self-Learning:** Online incremental centroid updates ($O(1)$ complexity) adapt reference models when new verified laboratory observations are submitted.
- **Dual GUI Support:** Includes both a modern **Streamlit web dashboard** (`app.py`) and a lightweight, 100% offline **Tkinter desktop GUI** (`gui_tk.py`).

---

## 👥 Project Team & Work Allocation (VIT Vellore)

**Institution:** Vellore Institute of Technology (VIT)  
**School:** School of Computer Science and Engineering (SCOPE) & School of Electrical Engineering (SELECT)  
**Course:** Basic Electrical & Electronics Engineering (BEEE) | Academic Year 2026–2027  
**Project Supervisor & Guide:** Prof. POOMPAVAI T, School of Electrical Engineering (SELECT)

| Student Member | Primary Technical Responsibilities | BEEE Theory & Software Focus |
| :--- | :--- | :--- |
| **KOTRA MANOJ KUMAR**<br>Reg. No: `23BCE2113`<br>B.Tech CSE (SCOPE) | • Electrical Circuit Design & BEEE Theory<br>• Kirchhoff's Laws (KCL/KVL) & Hand Derivations<br>• Falstad Simulation & SPICE Cross-Validation<br>• Fault Injection & Experiment Logging | Electrical Design Lead, Circuit Simulation Specialist |
| **Mayank Yadav**<br>Reg. No: `23BCE0119`<br>B.Tech CSE (SCOPE) | • Python Mathematical Model & Unit Testing<br>• Stochastic Dataset Generator & Standardization<br>• Nearest-Centroid Classifier & Self-Learning<br>• Streamlit Web App & Tkinter Desktop GUI | Python Architecture Lead, Diagnostic Software Engineer |
| **Both Members** | • Literature Review & References<br>• DOCX & PDF Project Report Preparation<br>• PowerPoint Presentation & Speaker Notes<br>• Viva Voce Preparation & Live Demonstration | Comprehensive Cross-Validation & Defense |

---

## 📐 Circuit Topology & Nominal Reference Values

```text
  Vs (+10V DC) ----[ R1: 1.0 kΩ ]----+---- Node A ----[ R3: 1.5 kΩ ]----+---- Node B
                                     |                                  |
                                 [ R2: 2.0 kΩ ]                     [ R4: 3.0 kΩ ]
                                     |                                  |
  GND (0V) --------------------------+----------------------------------+
```

### Theoretical Equations (KCL):
At Node A:
$$\frac{V_A - V_s}{R_1} + \frac{V_A}{R_2} + \frac{V_A - V_B}{R_3} = 0$$

At Node B:
$$\frac{V_B - V_A}{R_3} + \frac{V_B}{R_4} = 0 \implies V_B = V_A \left( \frac{R_4}{R_3 + R_4} \right) = \frac{2}{3} V_A$$

### Nominal Healthy Operating Point ($V_s = 10\text{ V}$):
- $R_p = R_2 \parallel (R_3 + R_4) = 2 \parallel 4.5 = \frac{18}{13}\text{ k}\Omega \approx 1.385\text{ k}\Omega$
- $R_{total} = R_1 + R_p = 1 + \frac{18}{13} = \frac{31}{13}\text{ k}\Omega \approx 2.385\text{ k}\Omega$
- $\mathbf{V_A} = \frac{180}{31}\text{ V} \approx \mathbf{5.806\text{ V}}$
- $\mathbf{V_B} = \frac{120}{31}\text{ V} \approx \mathbf{3.871\text{ V}}$
- $\mathbf{I_s} = \frac{130}{31}\text{ mA} \approx \mathbf{4.194\text{ mA}}$

---

## 📋 Catalog of All 13 Operating Conditions

| Code | Condition Label | Name | $V_A$ (V) | $V_B$ (V) | $I_s$ (mA) | Physical Circuit Behavior |
| :---: | :--- | :--- | :---: | :---: | :---: | :--- |
| **F0** | `F0_NORMAL` | Normal Operation | 5.806 | 3.871 | 4.194 | All resistors nominal (5% tolerance band). Healthy baseline. |
| **F1** | `F1_R1_OPEN` | R1 Open Circuit | 0.000 | 0.000 | 0.000 | Network disconnected from supply rail; de-energized. |
| **F2** | `F2_R2_OPEN` | R2 Open Circuit | 8.182 | 5.455 | 1.818 | Ground shunt lost; all current flows through R3-R4 series branch. |
| **F3** | `F3_R3_OPEN` | R3 Open Circuit | 6.667 | 0.000 | 3.333 | Node B isolated and grounded through R4; Node A forms 2-resistor divider. |
| **F4** | `F4_R4_OPEN` | R4 Open Circuit | 6.667 | 6.667 | 3.333 | Node B return path lost; zero current in R3, so Node B floats up to VA. |
| **F5** | `F5_R1_SHORT` | R1 Short Circuit | 10.000 | 6.667 | 7.222 | Node A clamped directly to +10V supply; maximum branch currents. |
| **F6** | `F6_R2_SHORT` | R2 Short Circuit | 0.000 | 0.000 | 10.000 | Node A shorted to Ground; full 10V drops across R1 (10 mA). |
| **F7** | `F7_R3_SHORT` | R3 Short Circuit | 5.455 | 5.455 | 4.545 | R3 shorted, joining Node A and B (VA = VB); R2 and R4 in parallel. |
| **F8** | `F8_R4_SHORT` | R4 Short Circuit | 4.615 | 0.000 | 5.385 | Node B shorted directly to Ground; Node A loaded by R2 \|\| R3. |
| **F9** | `F9_R1_INC50` | R1 +50% (1.5k) | 4.800 | 3.200 | 3.467 | Series resistance increases; larger drop before Node A. |
| **F10** | `F10_R2_INC50` | R2 +50% (3.0k) | 6.429 | 4.286 | 3.571 | Shunt resistance increases; Node A and B potentials rise. |
| **F11** | `F11_R3_DEC50` | R3 -50% (0.75k)| 5.660 | 4.528 | 4.340 | Stronger coupling between nodes; VB rises towards VA. |
| **F12** | `F12_R4_DEC50` | R4 -50% (1.5k) | 5.455 | 2.727 | 4.545 | Pull-down to ground strengthens; VB drops sharply to 2.73V. |

---

## 📂 Project Repository Structure

```text
d:\BEEE PROJECT\
├── requirements.txt           # Python package requirements
├── README.md                  # Complete project guide and documentation
├── app.py                     # Streamlit web graphical user interface
├── gui_tk.py                  # Offline desktop Tkinter graphical user interface
├── viva_preparation.md        # Comprehensive 20 Viva Q&As and demo script
├── src/
│   ├── __init__.py
│   ├── circuit_model.py       # DC Resistor Network nodal and analytical solver
│   ├── fault_scenarios.py     # 13 operating classes catalog and circuit factory
│   ├── dataset_generator.py   # Stochastic data generator (tolerances, noise, splits)
│   ├── classifier.py          # Baseline rule detector & Nearest-Centroid engine
│   ├── evaluation.py          # Metrics, confusion matrices, and sensitivity curves
│   └── falstad_export.py      # Falstad ASCII exporter, 1-click URLs, and CSV logger
├── tests/
│   ├── __init__.py
│   ├── test_circuit_model.py  # 14 unit tests for KCL/KVL, nominals, and fault physics
│   └── test_classifier.py     # 8 unit tests for standardizer, margins, and learning
├── scripts/
│   ├── generate_presentation.py # Builds 16-slide widescreen PowerPoint presentation
│   └── generate_report_docx.py  # Builds comprehensive 23-section Word report
├── data/                      # Synthetic CSV datasets & Falstad experiment log
│   ├── circuit_fault_train.csv
│   ├── circuit_fault_test.csv
│   ├── circuit_fault_full.csv
│   └── falstad_experiment_log.csv
├── results/                   # Exported performance metrics summary
│   └── evaluation_summary.txt
├── figures/                   # High-resolution PNG figures for report and slides
│   ├── circuit_schematic.png
│   ├── voltage_signatures_comparison.png
│   ├── confusion_matrix_classifier.png
│   ├── confusion_matrix_baseline.png
│   ├── noise_sensitivity_curve.png
│   └── tolerance_sensitivity_curve.png
├── presentation/              # Editable PPTX and native PDF slide deck
│   ├── Circuit_Doctor_Presentation.pptx
│   └── Circuit_Doctor_Presentation.pdf
└── report/                    # Editable DOCX and native PDF comprehensive report
    ├── Circuit_Doctor_Project_Report.docx
    └── Circuit_Doctor_Project_Report.pdf
```

---

## 🚀 Setup & Execution Guide

### 1. Requirements & Dependencies
The project runs on standard Python (>= 3.9). Install required packages:
```bash
pip install -r requirements.txt
```
*(Packages: `numpy`, `pandas`, `scikit-learn`, `matplotlib`, `python-docx`, `python-pptx`, `pytest`, `streamlit`)*

### 2. Run All Automated Unit Tests (22 Tests)
Run pytest to verify the mathematical model and diagnostic engine:
```bash
python -m pytest tests/ -v
```
*Expected: 22 passed in < 0.5 seconds.*

### 3. Run Experimental Evaluation Pipeline
Generates datasets, trains the classifiers, evaluates held-out test data, and plots all figures:
```bash
python -m src.evaluation
```
*Output: Saves 6 publication figures in `figures/` and metrics in `results/evaluation_summary.txt`.*

### 4. Run Desktop Graphical User Interface (Offline Tkinter)
Launch the lightweight desktop GUI (works 100% offline with zero web dependencies):
```bash
python gui_tk.py
```

### 5. Run Web Graphical User Interface (Streamlit)
Launch the interactive modern browser dashboard:
```bash
streamlit run app.py
```

### 6. Run Falstad Simulation Exporter
Generates Falstad schematic files and logs the CSV cross-validation table:
```bash
python -m src.falstad_export
```
Direct 1-Click Falstad Web Simulation:
[Launch Circuit in Falstad Simulator](https://www.falstad.com/circuit/circuitjs.html?cct=%24%201%200.000005%2010.20027730826997%2050%205%2043%0Av%20160%20304%20160%20144%200%200%2040%2010.0%200%200%200.5%0Aw%20160%20144%20240%20144%200%0Ar%20240%20144%20352%20144%200%201000.0%0Ar%20352%20144%20352%20304%200%202000.0%0Ar%20352%20144%20496%20144%200%201500.0%0Ar%20496%20144%20496%20304%200%203000.0%0Aw%20160%20304%20352%20304%200%0Aw%20352%20304%20496%20304%200%0Ag%20352%20304%20352%20336%200%0Ax%20352%20120%20390%20120%204%2018%20Node%20A%20%28VA%29%0Ax%20496%20120%20534%20120%204%2018%20Node%20B%20%28VB%29%0Ax%20240%2080%20450%2080%204%2020%20Nominal%20DC%20Resistor%20Network)

---

## 📊 Experimental Results Summary

- **Total Dataset Size:** 1,950 samples across 13 balanced classes (150 samples/class).
- **Training Partition:** 1,560 samples (120 per class, 80%).
- **Testing Partition:** 390 samples (30 per class, 20%).
- **Method B (Standardized Nearest Centroid):** **100.00% Accuracy** (Macro Precision: 1.0000, Recall: 1.0000, F1: 1.0000).
- **Method A (Baseline Rule Detector):** **100.00% Accuracy** on nominal test set.
- **Falstad SPICE Discrepancy:** Maximum absolute deviation $\le 0.00045\text{ V}$, strictly reflecting the 3-decimal display limit of Falstad's voltmeters.

---

## 🛠️ Troubleshooting Guide

- **Streamlit network timeout during pip install:** Run `python gui_tk.py` to immediately launch the desktop GUI using Python's built-in Tkinter framework with zero package dependencies.
- **ModuleNotFoundError: No module named 'src':** Execute Python commands using the `-m` switch from the repository root (e.g. `python -m src.evaluation` or `python -m pytest tests/`).
- **Permission errors with COM objects when exporting PDFs:** Re-run `python scripts/generate_report_docx.py` and `python scripts/generate_presentation.py` to ensure documents are not locked by Microsoft Word or PowerPoint.

---

*Developed for B.Tech BEEE Coursework. Academic Year 2026–2027.*
